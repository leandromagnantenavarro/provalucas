// Estrutura completa do site educativo "Provas do Lucas Miwa Navarro"
// Inclui navegação por meses, matérias, temas e integração com caligrafia

import SignaturePad from 'react-signature-canvas';
import { useRef, useState } from 'react';
import { Button } from "@/components/ui/button";

function Caligrafia({ palavras, onValidar }) {
  const [indice, setIndice] = useState(0);
  const [assinaturas, setAssinaturas] = useState([]);
  const sigPad = useRef(null);

  const salvarPalavra = () => {
    const data = sigPad.current.toData();
    setAssinaturas([...assinaturas, data]);
    sigPad.current.clear();
    if (indice + 1 < palavras.length) {
      setIndice(indice + 1);
    } else {
      onValidar();
    }
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow-xl text-black mt-6">
      <h3 className="text-lg font-semibold mb-2">Escreva a palavra:</h3>
      <div className="text-2xl font-bold text-center mb-4">{palavras[indice]}</div>
      <SignaturePad
        ref={sigPad}
        canvasProps={{ width: 300, height: 150, className: "border border-gray-300" }}
      />
      <Button onClick={salvarPalavra} className="mt-4">Salvar e próxima</Button>
    </div>
  );
}

const palavrasCaligrafia = {
  "Sinônimos": ["bonito", "alegre", "veloz", "enorme", "belo"],
  "Antônimos": ["triste", "baixo", "escuro", "frio", "sujo"],
  "Interpretação de texto": ["parque", "sorvete", "água", "sol", "molhado"],
  "Estudos sobre narração de texto": ["história", "personagem", "tempo", "espaço", "narrador"],
  "Sílabas": ["casa", "livro", "pato", "doce", "mesa"],
  "Classificação de sílabas": ["sol", "nuvem", "boneca", "elefante", "papagaio"],
  "Hiato": ["saída", "baú", "país", "poeta", "juízo"],
  "Ditongo": ["mãe", "pai", "papel", "caixa", "boi"],
  "Tritongo": ["Uruguai", "iguais", "saguão", "enxaguou", "desaguou"],
  "Uso de vogais e i o u em palavras": ["ilha", "uva", "oceano", "livro", "único"],
  "Parlenda": ["batatinha", "nasce", "esparrama", "menina", "janela"]
};

export default function App() {
  const [mesSelecionado, setMesSelecionado] = useState(null);
  const [materiaSelecionada, setMateriaSelecionada] = useState(null);
  const [temaSelecionado, setTemaSelecionado] = useState(null);

  const meses = ["Abril", "Maio", "Junho", "Julho"];

  const materias = {
    Abril: ["Português"],
    Maio: ["Matemática"],
    Junho: ["História"],
    Julho: ["Ciências"]
  };

  const temasPorMateria = {
    "Português": Object.keys(palavrasCaligrafia)
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-gray-300 text-white p-6">
      <h1 className="text-3xl font-bold text-center mb-6">Provas do Lucas Miwa Navarro</h1>

      {!mesSelecionado ? (
        <div className="grid grid-cols-2 gap-4">
          {meses.map(m => (
            <Button key={m} onClick={() => setMesSelecionado(m)}>{m}</Button>
          ))}
        </div>
      ) : !materiaSelecionada ? (
        <div>
          <Button onClick={() => setMesSelecionado(null)} className="mb-4">← Voltar</Button>
          <h2 className="text-2xl font-semibold mb-4">Matérias de {mesSelecionado}</h2>
          {materias[mesSelecionado]?.map(m => (
            <Button key={m} onClick={() => setMateriaSelecionada(m)} className="block my-2">{m}</Button>
          ))}
        </div>
      ) : !temaSelecionado ? (
        <div>
          <Button onClick={() => setMateriaSelecionada(null)} className="mb-4">← Voltar</Button>
          <h2 className="text-2xl font-semibold mb-4">Temas de {materiaSelecionada}</h2>
          {temasPorMateria[materiaSelecionada]?.map(t => (
            <Button key={t} onClick={() => setTemaSelecionado(t)} className="block my-2">{t}</Button>
          ))}
        </div>
      ) : (
        <div>
          <Button onClick={() => setTemaSelecionado(null)} className="mb-4">← Voltar</Button>
          <h2 className="text-2xl font-bold">{temaSelecionado}</h2>
          <Caligrafia
            palavras={palavrasCaligrafia[temaSelecionado] || ["casa", "bola", "livro", "sol", "lua"]}
            onValidar={() => alert("Parabéns! Você finalizou a caligrafia.")}
          />
        </div>
      )}
    </div>
  );
}